package com.borneocode.belajarsqllite;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kodir Zaelani on 09/03/2018.
 */

public class TodoListAdapter extends RecyclerView.Adapter<TodoListAdapter.TodoViewHolder> {
    ArrayList<Item> itemArrayList;
    Context context;
    MyDatabase database;
    ArrayList<Item> todoList = new ArrayList<>();

    CharSequence text = "Data berhasil dihapus!";
    int duration = Toast.LENGTH_SHORT;

    public TodoListAdapter(ArrayList<Item> itemArrayList, Context context) {
        this.itemArrayList = itemArrayList;
        this.context = context;

        database = new MyDatabase(context);
    }

    @Override
    public TodoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new TodoViewHolder(view);
    }

//    @Override
//    public void onBindViewHolder(TodoViewHolder holder, int position) {
//        Item item = itemArrayList.get(position);
//        holder.todoText.setText(item.getName());
//    }

    @Override
    public void onBindViewHolder(TodoViewHolder holder, int position) {
        final Item item = itemArrayList.get(position);
        holder.todoText.setText(item.getName());
        // Perubahan untuk menambhakan icon
        holder.editImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AddEditActivity.class);
                intent.putExtra("ITEM", item);
                context.startActivity(intent);
            }
        });

        holder.doneImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabase database = new MyDatabase(context);
                showDialogdelete(item);
               // database.deleteItem(item.getId());


            }
        });
    }

    @Override
    public int getItemCount() {
        return itemArrayList.size();
    }

    public class TodoViewHolder extends RecyclerView.ViewHolder {
        TextView todoText;
        ImageView editImageView;
        ImageView doneImageView;

        public TodoViewHolder(View itemView) {
            super(itemView);

            todoText = itemView.findViewById(R.id.todo_name);
            editImageView = itemView.findViewById(R.id.edit_todo);
            doneImageView = itemView.findViewById(R.id.done_todo);
        }
    }

    private void showDialogdelete(final Item item) {
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        // set title dialog
        alertDialogBuilder.setTitle("Hapus Data");
        // set pesan dari dialog
        alertDialogBuilder
                .setMessage("Klik Ya untuk menghapus!")
                .setIcon(R.mipmap.ic_launcher)
                .setCancelable(false)
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {
                        //Jika tombol diklik, maka akan menutup activity ini
                        database.deleteItem(item.getId());
                        itemArrayList.clear();
                        itemArrayList.addAll(database.getAll());
                        notifyDataSetChanged();
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();

                    }
                })

                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {
                        // Jika tombol ini diklik, akan menutup dialog
                        // dan tidak terjadi apa-apa
                        dialogInterface.cancel();
                    }
                });

        //membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();

    }
}
